package ru.togc.storyplayer

import org.junit.Assert.assertEquals
import org.junit.Test
import ru.togc.storyplayer.data.Story

class StoryModelTest {
    @Test fun storyKeepsIndependentResumePosition() {
        val first = Story(id = 1, title = "Первая", uri = "content://first", sourceName = "first.mp3", positionMs = 2_244_000)
        val second = Story(id = 2, title = "Вторая", uri = "content://second", sourceName = "second.mp3", positionMs = 510_000)
        assertEquals(2_244_000L, first.positionMs)
        assertEquals(510_000L, second.positionMs)
        assertEquals("content://first", first.uri)
        assertEquals("content://second", second.uri)
    }

    @Test fun storyDefaultsAreSafeForNewImports() {
        val story = Story(title = "История", uri = "content://audio", sourceName = "story.ogg")
        assertEquals(0L, story.positionMs)
        assertEquals(false, story.isFavorite)
        assertEquals(0, story.playCount)
    }
}
