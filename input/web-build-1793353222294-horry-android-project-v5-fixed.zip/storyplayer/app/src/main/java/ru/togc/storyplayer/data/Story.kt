package ru.togc.storyplayer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class Story(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String = "Неизвестный автор",
    val uri: String,
    val sourceName: String,
    val durationMs: Long = 0,
    val positionMs: Long = 0,
    val lastPlayedAt: Long = 0,
    val addedAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val isCompleted: Boolean = false,
    val playCount: Int = 0,
    val listenedMs: Long = 0
)

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val positionMs: Long,
    val title: String,
    val note: String = "",
    val color: Int = 0xFFE57373.toInt(),
    val createdAt: Long = System.currentTimeMillis()
)
