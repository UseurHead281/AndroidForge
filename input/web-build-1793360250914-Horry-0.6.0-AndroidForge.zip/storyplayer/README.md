# Horry 0.5.0

Локальный Android-аудиоплеер на Kotlin, Jetpack Compose, Material 3, Media3 и Room.

## Обновления 0.5.0
- Главный экран-панель с количеством историй, незавершёнными прослушиваниями и суммарным временем.
- Визуальная карточка продолжения и подборки недавно добавленных/избранных историй.
- Библиотечные фильтры: все, избранное, не закончено, не начато.
- Сортировка по последнему прослушиванию, названию, дате добавления, частоте прослушивания и прогрессу.
- Быстрая очистка поискового запроса.
- Расширенное меню действий у каждой записи.
- Пружинное изменение размеров карточек и анимированный эквалайзер в плеере.
- Управление перемешиванием, режимами повтора и восемью скоростями воспроизведения.

## Сборка
Открыть папку `storyplayer` в Android Studio и выполнить Gradle Sync, затем `Build > Build APK(s)`.
Для облачной сборки загружать ZIP целиком, содержащий корневую папку `storyplayer`.

## Технологии
- Kotlin / Jetpack Compose / Material 3
- AndroidX Media3 ExoPlayer + MediaSession
- Room + DataStore
- Min SDK 26, Compile SDK 35, Java 17

Проверка компиляции должна быть выполнена в Android SDK/Gradle окружении. Архив исходников сам по себе не является APK.


## Horry 0.6.0 — stability update

- Fixed the missing Compose `InfiniteTransition.animateFloat` extension import that caused the Kotlin errors around `MainActivity.kt:501`. The type-inference and overload errors reported nearby were downstream compiler errors from that unresolved extension.
- Kept the existing Material 3 interface, animated equalizer, spring-based UI motion, library search, favorites, bookmarks, playback progress, playback speed, repeat/shuffle, sleep timer, theme palette, AMOLED mode, font scaling, and system media controls.
- Bumped Android version metadata to 0.6.0 (versionCode 6).

Build this project with AndroidForge using the ZIP archive. A successful source-level correction is not a substitute for a real Android Gradle build; verify the APK build in AndroidForge before installing.
