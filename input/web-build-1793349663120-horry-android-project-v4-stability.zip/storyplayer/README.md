# Horry — личный аудиоплеер для Android

Horry 0.3.0 — локальный плеер для личной коллекции аудиоисторий. Проект использует Kotlin, Jetpack Compose, Material 3, Media3 ExoPlayer, MediaSessionService, Room и DataStore.

## Уже реализовано
- Импорт локальных аудиофайлов через системный выбор Android.
- Локальная библиотека, поиск, избранное и редактирование названия/автора.
- Воспроизведение через Media3 и системная медиасессия для уведомления/шторки Android и экрана блокировки.
- Мини-плеер в приложении.
- Сохранение позиции, закладки и таймер сна.
- Настраиваемый цвет акцента (10 палитр), AMOLED-тема, форма значка мини-плеера и шаг перемотки 5/10/15/30/45/60 секунд.
- Плавное изменение цвета акцента, скруглённые стилизованные поля ввода и плавающая нижняя навигация.
- Кнопка «назад» на экране плеера возвращает на главный экран.
- Ползунок прогресса с перетаскиванием и предпросмотром позиции; воспроизведение перемещается после отпускания ползунка, а обновление шкалы вне перемотки анимировано.
- Настройка масштаба текста с сохранением параметра.
- Опция «Удалять после завершения»: автоматически убирает завершённые истории из библиотеки и удаляет их закладки; исходные аудиофайлы на устройстве не затрагиваются. Опция выключена по умолчанию и включается в настройках.

## Сборка
1. Открой папку `storyplayer` в Android Studio.
2. Установи Android SDK 35 и JDK 17.
3. Выполни Gradle Sync.
4. Выбери **Build → Build APK(s)**.
5. Debug APK обычно появляется в `app/build/outputs/apk/debug/app-debug.apk`.

Минимальная версия Android: 8.0 (API 26). Сборка и работа на устройстве должны быть проверены в Android Studio; этот архив сам по себе не является APK.

## Примечание
Системное уведомление управления аудио создаётся AndroidX Media3 на основе MediaSessionService и активного воспроизведения. Отображение может зависеть от версии Android и настроек уведомлений устройства.


## Horry 0.4.0 — stability pass

This revision focuses on fixing known rough edges rather than claiming the app is finished:

- Player content now scrolls on short screens instead of being clipped below the fold.
- Palette and seek-step controls wrap onto multiple rows on narrow phones.
- The playback progress animation uses a spring when not scrubbing; direct dragging remains immediate.
- The playback listener is detached when the activity releases its MediaController connection.
- Auto-removal identifies the item that actually finished during an automatic playlist transition, instead of relying on whichever story happens to be selected in the UI. It only removes the library record and bookmarks, not the original audio file.
- Listening-time accumulation is separated from playback position and is counted only while ExoPlayer reports active playback while the app process is alive.
- Periodic progress writes no longer rewrite the story's last-played timestamp.

Build validation: source archive structure was checked. An Android Gradle build and device runtime test were not available in this environment; compile/runtime behavior still needs confirmation through AndroidForge and on-device testing.
