@file:OptIn(ExperimentalMaterial3Api::class)
package com.mystories.player.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import com.mystories.player.data.StoryEntity

@Composable
fun MainScreen(vm: MainViewModel) {
    val cfg by vm.settings.collectAsState()
    val st by vm.player.collectAsState()
    val busy by vm.busy.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var author by rememberSaveable { mutableStateOf<String?>(null) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.importFiles(it) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::addFolder) }
    val addFiles = { pickFiles.launch(arrayOf("audio/*", "application/ogg")) }
    val addFolder = { pickTree.launch(null) }

    val open: (StoryEntity) -> Unit = { vm.play(it); showPlayer = true }
    val openAt: (StoryEntity, Long) -> Unit = { s, p -> vm.play(s, p); showPlayer = true }

    BackHandler(showPlayer) { vm.saveNow(); showPlayer = false }
    BackHandler(!showPlayer && author != null) { author = null }

    val enter = if (cfg.reduceAnim) EnterTransition.None else slideInVertically { it } + fadeIn()
    val exit = if (cfg.reduceAnim) ExitTransition.None else slideOutVertically { it } + fadeOut()

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                Column {
                    if (st.storyId != 0L) MiniPlayer(vm) { showPlayer = true }
                    NavigationBar {
                        listOf("Главная" to Icons.Rounded.Home, "Библиотека" to Icons.Rounded.LibraryMusic, "Закладки" to Icons.Rounded.Bookmarks,
                            "Авторы" to Icons.Rounded.Person, "Настройки" to Icons.Rounded.Settings).forEachIndexed { i, (n, ic) ->
                            NavigationBarItem(tab == i, { tab = i; author = null }, { Icon(ic, n) }, label = { Text(n, maxLines = 1) }, alwaysShowLabel = false)
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                AnimatedContent(tab to author, label = "tabs", transitionSpec = {
                    if (cfg.reduceAnim) EnterTransition.None togetherWith ExitTransition.None else fadeIn() togetherWith fadeOut()
                }) { (t, a) ->
                    when {
                        t == 3 && a != null -> AuthorDetail(vm, a, { author = null }, { author = it }, open)
                        else -> when (t) {
                            0 -> HomeScreen(vm, open, addFiles, addFolder) { tab = 1 }
                            1 -> LibraryScreen(vm, open, addFiles, addFolder)
                            2 -> BookmarksScreen(vm, openAt)
                            3 -> AuthorsScreen(vm) { author = it }
                            else -> SettingsScreen(vm, addFiles, addFolder)
                        }
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }
        AnimatedVisibility(showPlayer, enter = enter, exit = exit) { PlayerScreen(vm) { showPlayer = false } }
    }
}
