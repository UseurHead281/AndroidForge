package com.mystories.player.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "stories", indices = [Index(value = ["uri"], unique = true)])
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String = "",
    val series: String = "",
    val partNumber: Int = 0,
    val uri: String,
    val fileName: String,
    val sourceId: Long? = null,
    val folderName: String = "",
    val coverPath: String? = null,
    val durationMs: Long = 0,
    val positionMs: Long = 0,
    val lastPlayedAt: Long = 0,
    val playCount: Int = 0,
    val listenedSec: Long = 0,
    val favorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis(),
    val description: String = "",
    val tags: String = "",
    val completed: Boolean = false,
    val missing: Boolean = false,
    val speed: Float = 0f,
    val sortOrder: Int = 0,
    val sizeBytes: Long = 0
)

fun StoryEntity.percent(): Float =
    if (completed) 100f else if (durationMs > 0) (positionMs * 100f / durationMs).coerceIn(0f, 100f) else 0f

fun StoryEntity.status(): String = when {
    completed -> "Завершено"
    positionMs > 0 -> "В процессе"
    else -> "Новое"
}

@Entity(
    tableName = "bookmarks",
    foreignKeys = [ForeignKey(StoryEntity::class, ["id"], ["storyId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("storyId")]
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val positionMs: Long,
    val title: String,
    val color: Long = 0xFFE53935,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val name: String,
    val lastScan: Long = 0,
    val fileCount: Int = 0
)

@Entity(tableName = "listen_log")
data class ListenLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val at: Long,
    val seconds: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM stories") fun stories(): Flow<List<StoryEntity>>
    @Query("SELECT * FROM stories") suspend fun allStories(): List<StoryEntity>
    @Query("SELECT * FROM stories WHERE id=:id") suspend fun story(id: Long): StoryEntity?
    @Query("SELECT * FROM stories WHERE uri=:uri LIMIT 1") suspend fun storyByUri(uri: String): StoryEntity?
    @Query("SELECT * FROM stories WHERE sourceId=:sid") suspend fun storiesBySource(sid: Long): List<StoryEntity>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertStory(s: StoryEntity): Long
    @Update suspend fun updateStory(s: StoryEntity)
    @Query("DELETE FROM stories WHERE id=:id") suspend fun deleteStory(id: Long)
    @Query("UPDATE stories SET positionMs=:pos, lastPlayedAt=:now WHERE id=:id") suspend fun savePosition(id: Long, pos: Long, now: Long)
    @Query("UPDATE stories SET completed=:c WHERE id=:id") suspend fun setCompleted(id: Long, c: Boolean)
    @Query("UPDATE stories SET completed=1, positionMs=:pos WHERE id=:id") suspend fun markEnded(id: Long, pos: Long)
    @Query("UPDATE stories SET playCount=playCount+1, lastPlayedAt=:now WHERE id=:id") suspend fun incPlay(id: Long, now: Long)
    @Query("UPDATE stories SET listenedSec=listenedSec+:sec WHERE id=:id") suspend fun addListened(id: Long, sec: Long)
    @Query("UPDATE stories SET speed=:v WHERE id=:id") suspend fun setSpeed(id: Long, v: Float)
    @Query("UPDATE stories SET missing=:m WHERE id=:id") suspend fun setMissing(id: Long, m: Boolean)
    @Query("UPDATE stories SET favorite=:f WHERE id=:id") suspend fun setFavorite(id: Long, f: Boolean)
    @Query("UPDATE stories SET author=:new WHERE author=:old") suspend fun renameAuthor(old: String, new: String)
    @Query("SELECT * FROM stories WHERE series=:series AND series!='' AND partNumber>:part ORDER BY partNumber ASC LIMIT 1")
    suspend fun nextPart(series: String, part: Int): StoryEntity?
    @Query("SELECT * FROM stories WHERE series=:series AND series!='' AND partNumber<:part AND partNumber>0 ORDER BY partNumber DESC LIMIT 1")
    suspend fun prevPart(series: String, part: Int): StoryEntity?
    @Query("UPDATE stories SET sourceId=NULL WHERE sourceId=:sid") suspend fun detachSource(sid: Long)
    @Query("UPDATE stories SET listenedSec=0, playCount=0") suspend fun resetStoryStats()

    @Query("SELECT * FROM bookmarks ORDER BY storyId, positionMs") fun bookmarks(): Flow<List<BookmarkEntity>>
    @Insert suspend fun insertBookmark(b: BookmarkEntity): Long
    @Update suspend fun updateBookmark(b: BookmarkEntity)
    @Delete suspend fun deleteBookmark(b: BookmarkEntity)

    @Query("SELECT * FROM sources") fun sources(): Flow<List<SourceEntity>>
    @Query("SELECT * FROM sources") suspend fun allSources(): List<SourceEntity>
    @Query("SELECT * FROM sources WHERE uri=:uri LIMIT 1") suspend fun sourceByUri(uri: String): SourceEntity?
    @Insert suspend fun insertSource(s: SourceEntity): Long
    @Update suspend fun updateSource(s: SourceEntity)
    @Query("DELETE FROM sources WHERE id=:id") suspend fun deleteSource(id: Long)

    @Insert suspend fun insertLog(l: ListenLogEntity)
    @Query("SELECT COALESCE(SUM(seconds),0) FROM listen_log WHERE at>=:since") fun listenedSince(since: Long): Flow<Long>
    @Query("DELETE FROM listen_log") suspend fun clearLog()
}

@Database(
    entities = [StoryEntity::class, BookmarkEntity::class, SourceEntity::class, ListenLogEntity::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() { abstract fun dao(): AppDao }
