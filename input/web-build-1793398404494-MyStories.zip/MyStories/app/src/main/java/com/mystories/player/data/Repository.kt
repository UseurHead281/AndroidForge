package com.mystories.player.data

class Repository(val dao: AppDao) {
    val stories = dao.stories()
    val bookmarks = dao.bookmarks()
    val sources = dao.sources()

    suspend fun story(id: Long) = dao.story(id)
    suspend fun savePosition(id: Long, pos: Long) { if (id > 0 && pos >= 0) dao.savePosition(id, pos, System.currentTimeMillis()) }
    suspend fun addListen(id: Long, sec: Long) {
        if (id <= 0 || sec <= 0) return
        dao.addListened(id, sec); dao.insertLog(ListenLogEntity(storyId = id, at = System.currentTimeMillis(), seconds = sec))
    }
    suspend fun incPlay(id: Long) = dao.incPlay(id, System.currentTimeMillis())
    suspend fun markEnded(id: Long, fallbackDuration: Long) {
        val s = dao.story(id) ?: return
        dao.markEnded(id, if (s.durationMs > 0) s.durationMs else fallbackDuration.coerceAtLeast(0))
    }
    suspend fun setCompleted(id: Long, c: Boolean) = dao.setCompleted(id, c)
    suspend fun neighbor(id: Long, next: Boolean): StoryEntity? {
        val s = dao.story(id) ?: return null
        if (s.series.isBlank()) return null
        return if (next) dao.nextPart(s.series, s.partNumber) else dao.prevPart(s.series, s.partNumber)
    }
    suspend fun update(s: StoryEntity) = dao.updateStory(s)
    suspend fun setFavorite(id: Long, f: Boolean) = dao.setFavorite(id, f)
    suspend fun setSpeed(id: Long, v: Float) = dao.setSpeed(id, v)
    suspend fun remove(id: Long) = dao.deleteStory(id)
    suspend fun renameAuthor(old: String, new: String) = dao.renameAuthor(old, new)
    suspend fun resetStats() { dao.clearLog(); dao.resetStoryStats() }
    fun listenedSince(t: Long) = dao.listenedSince(t)

    suspend fun addBookmark(b: BookmarkEntity) = dao.insertBookmark(b)
    suspend fun updateBookmark(b: BookmarkEntity) = dao.updateBookmark(b)
    suspend fun deleteBookmark(b: BookmarkEntity) = dao.deleteBookmark(b)
}
