package com.mystories.player.service

import android.os.SystemClock
import androidx.media3.common.Player
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class SleepTimer(private val scope: CoroutineScope) {
    data class State(val remainingMs: Long = 0, val endOfStory: Boolean = false) {
        val active get() = remainingMs > 0 || endOfStory
    }
    private val _s = MutableStateFlow(State())
    val state: StateFlow<State> = _s
    var player: Player? = null
    var fadeSec = 10
    private var job: Job? = null
    private var endAt = 0L

    fun startMinutes(min: Int) { endAt = SystemClock.elapsedRealtime() + min * 60_000L; run() }
    fun addMinutes(min: Int) { if (_s.value.remainingMs > 0) endAt += min * 60_000L else startMinutes(min) }
    fun endOfStory() { job?.cancel(); player?.volume = 1f; _s.value = State(0, true) }
    fun cancel() { job?.cancel(); player?.volume = 1f; _s.value = State() }
    fun finish() { job?.cancel(); player?.let { it.pause(); it.volume = 1f }; _s.value = State() }

    private fun run() {
        job?.cancel()
        job = scope.launch {
            while (true) {
                val rem = endAt - SystemClock.elapsedRealtime()
                if (rem <= 0) break
                _s.value = State(rem)
                val fade = fadeSec * 1000L
                if (fade > 0 && rem <= fade) player?.volume = (rem / fade.toFloat()).coerceIn(0f, 1f)
                delay(if (rem <= fade) 200 else 500)
            }
            finish()
        }
    }
}
