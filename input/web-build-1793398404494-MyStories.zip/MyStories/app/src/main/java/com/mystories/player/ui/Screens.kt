@file:OptIn(ExperimentalMaterial3Api::class)
package com.mystories.player.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mystories.player.data.*
import java.util.Calendar

@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (StoryEntity) -> Unit, onImportFiles: () -> Unit, onImportFolder: () -> Unit, onLibrary: () -> Unit) {
    val stories by vm.stories.collectAsState()
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = when { hour < 6 -> "Доброй ночи"; hour < 12 -> "Доброе утро"; hour < 18 -> "Добрый день"; else -> "Добрый вечер" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text(greet, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 24.dp, 16.dp, 8.dp)) }
        if (stories.isEmpty()) {
            item {
                EmptyState("Здесь будут ваши истории", "Добавьте аудиофайлы или целую папку — приложение запомнит, где вы остановились.", "Добавить файлы", onImportFiles)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { TextButton(onImportFolder) { Text("Или выбрать папку") } }
            }
            return@LazyColumn
        }
        val last = stories.filter { it.lastPlayedAt > 0 }.maxByOrNull { it.lastPlayedAt }
        if (last != null) item {
            Card(Modifier.fillMaxWidth().padding(16.dp, 8.dp).clickable { onOpen(last) }, shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(last, Modifier.size(88.dp))
                    Column(Modifier.padding(start = 16.dp).weight(1f)) {
                        Text("Продолжить слушать", style = MaterialTheme.typography.labelMedium)
                        Text(last.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        Text("с ${fmt(last.positionMs)} из ${fmt(last.durationMs)}", style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator({ last.percent() / 100f }, Modifier.fillMaxWidth().padding(top = 8.dp))
                    }
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(40.dp))
                }
            }
        }
        fun row(title: String, list: List<StoryEntity>) {
            if (list.isEmpty()) return
            item { SectionTitle(title) }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) { items(list, key = { it.id }) { StoryTile(it, { onOpen(it) }) } } }
        }
        row("Не закончены", stories.filter { it.positionMs > 0 && !it.completed && it.id != last?.id }.sortedByDescending { it.lastPlayedAt })
        row("Недавно добавленные", stories.sortedByDescending { it.addedAt }.take(15))
        row("Недавно прослушанные", stories.filter { it.lastPlayedAt > 0 }.sortedByDescending { it.lastPlayedAt }.take(15))
        row("Избранное", stories.filter { it.favorite })
        val authors = stories.filter { it.author.isNotBlank() }.groupBy { it.author }
        if (authors.isNotEmpty()) {
            item { SectionTitle("Авторы") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(authors.entries.sortedByDescending { it.value.size }.take(10).toList(), key = { it.key }) { (name, list) ->
                        AssistChip(onClick = onLibrary, label = { Text("$name · ${list.size}") })
                    }
                }
            }
        }
        item { Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onImportFiles) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text("Файлы") }
            FilledTonalButton(onImportFolder) { Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Папка") }
            OutlinedButton(onLibrary) { Text("В библиотеку") }
        } }
    }
}

private val sortNames = listOf("Название", "Автор", "Дата добавления", "Последнее прослушивание", "Длительность", "Завершение")
private val groupNames = listOf("Без группировки", "По авторам", "По сериям", "По папкам")
private val filterNames = listOf("Все", "Избранное", "Не прослушано", "В процессе", "Завершено", "Недавно добавлено")

@Composable
private fun Selector(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        AssistChip(onClick = { open = true }, label = { Text("$label: ${options[selected]}") })
        DropdownMenu(open, { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onSelect(i) }) }
        }
    }
}

@Composable
fun LibraryScreen(vm: MainViewModel, onOpen: (StoryEntity) -> Unit, onImportFiles: () -> Unit, onImportFolder: () -> Unit) {
    val stories by vm.stories.collectAsState()
    val s by vm.settings.collectAsState()
    var q by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableIntStateOf(0) }
    val week = remember { System.currentTimeMillis() - 7L * 86_400_000 }
    val groups = remember(stories, q, filter, s.libSort, s.libGroup) {
        var l = stories.filter { st ->
            when (filter) {
                1 -> st.favorite; 2 -> !st.completed && st.positionMs == 0L && st.playCount == 0
                3 -> st.positionMs > 0 && !st.completed; 4 -> st.completed; 5 -> st.addedAt >= week; else -> true
            }
        }
        if (q.isNotBlank()) l = l.filter { st ->
            listOf(st.title, st.author, st.series, st.tags, st.fileName).any { it.contains(q.trim(), ignoreCase = true) }
        }
        l = when (s.libSort) {
            0 -> l.sortedBy { it.title.lowercase() }; 1 -> l.sortedBy { it.author.lowercase() }
            2 -> l.sortedByDescending { it.addedAt }; 3 -> l.sortedByDescending { it.lastPlayedAt }
            4 -> l.sortedByDescending { it.durationMs }; else -> l.sortedByDescending { it.percent() }
        }
        when (s.libGroup) {
            1 -> l.groupBy { it.author.ifBlank { "Без автора" } }.toList()
            2 -> l.groupBy { it.series.ifBlank { "Вне серий" } }.map { (k, v) -> k to v.sortedBy { it.partNumber } }
            3 -> l.groupBy { it.folderName.ifBlank { "Без папки" } }.toList()
            else -> listOf<Pair<String?, List<StoryEntity>>>(null to l)
        }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 12.dp, 16.dp, 0.dp), singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Название, автор, серия, тег, файл") },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, "Очистить") } },
            shape = RoundedCornerShape(28.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            filterNames.forEachIndexed { i, n -> FilterChip(filter == i, { filter = i }, label = { Text(n) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Selector("Сортировка", sortNames, s.libSort) { vm.set(K.libSort, it) }
            Selector("Группы", groupNames, s.libGroup) { vm.set(K.libGroup, it) }
            IconButton({ vm.set(K.libView, if (s.libView == 0) 1 else 0) }) {
                if (s.libView == 0) Icon(Icons.AutoMirrored.Rounded.ViewList, "Список") else Icon(Icons.Rounded.GridView, "Сетка")
            }
        }
        if (stories.isEmpty()) EmptyState("Библиотека пуста", "Добавьте первую историю.", "Добавить файлы", onImportFiles)
        else if (groups.all { it.second.isEmpty() }) EmptyState("Ничего не найдено", "Измените запрос или фильтр.")
        else LazyVerticalGrid(
            if (s.libView == 0) GridCells.Adaptive(140.dp) else GridCells.Fixed(1),
            contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 24.dp), modifier = Modifier.fillMaxSize()
        ) {
            groups.forEach { (name, list) ->
                if (name != null && list.isNotEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("$name · ${list.size}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(4.dp, 12.dp, 4.dp, 4.dp))
                }
                items(list, key = { "${name}_${it.id}" }) { st ->
                    if (s.libView == 0) Box {
                        StoryTile(st, { onOpen(st) })
                        Box(Modifier.align(Alignment.TopEnd)) { StoryMenuButton(st, vm) }
                    } else StoryRow(st, vm) { onOpen(st) }
                }
            }
        }
    }
}

@Composable
fun BookmarksScreen(vm: MainViewModel, onOpen: (StoryEntity, Long) -> Unit) {
    val bms by vm.bookmarks.collectAsState()
    val stories by vm.stories.collectAsState()
    var edit by remember { mutableStateOf<BookmarkEntity?>(null) }
    edit?.let { BookmarkDialog(it, { b -> vm.updateBookmark(b) }, { edit = null }) }
    if (bms.isEmpty()) { EmptyState("Закладок пока нет", "Во время прослушивания нажмите на флажок в плеере, чтобы отметить важный момент."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("Закладки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 24.dp, 16.dp, 8.dp)) }
        bms.groupBy { it.storyId }.forEach { (sid, list) ->
            val st = stories.find { it.id == sid } ?: return@forEach
            item(key = "h$sid") { SectionTitle(st.title) }
            items(list, key = { it.id }) { b ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(st, b.positionMs) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Flag, null, tint = Color(b.color))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(b.title, style = MaterialTheme.typography.titleSmall)
                        Text(fmt(b.positionMs) + if (b.note.isNotBlank()) " · ${b.note}" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton({ edit = b }) { Icon(Icons.Rounded.Edit, "Изменить") }
                    IconButton({ vm.deleteBookmark(b) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                }
            }
        }
    }
}

@Composable
fun AuthorsScreen(vm: MainViewModel, onAuthor: (String) -> Unit) {
    val stories by vm.stories.collectAsState()
    val groups = remember(stories) { stories.groupBy { it.author.ifBlank { "Без автора" } }.toList().sortedBy { it.first.lowercase() } }
    if (groups.isEmpty()) { EmptyState("Авторов пока нет", "Они появятся после добавления историй."); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Text("Авторы", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 24.dp, 16.dp, 8.dp)) }
        items(groups, key = { it.first }) { (name, list) ->
            Row(Modifier.fillMaxWidth().clickable { onAuthor(name) }.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(list.first().copy(title = name, coverPath = null), Modifier.size(56.dp).clip(RoundedCornerShape(50)))
                Column(Modifier.padding(start = 16.dp)) {
                    Text(name, style = MaterialTheme.typography.titleMedium)
                    Text("Историй: ${list.size} · слушал: ${fmtDur(list.sumOf { it.listenedSec })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun AuthorDetail(vm: MainViewModel, name: String, onBack: () -> Unit, onRenamed: (String) -> Unit, onOpen: (StoryEntity) -> Unit) {
    val stories by vm.stories.collectAsState()
    val list = stories.filter { it.author.ifBlank { "Без автора" } == name }
    var rename by remember { mutableStateOf(false) }
    if (rename) TextDialog("Переименовать автора", if (name == "Без автора") "" else name, "Имя (совпадающее имя объединит авторов)", { vm.renameAuthor(if (name == "Без автора") "" else name, it); onRenamed(it); rename = false }, { rename = false })
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") }
            Text(name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            IconButton({ rename = true }) { Icon(Icons.Rounded.Edit, "Переименовать") }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) { items(list, key = { it.id }) { StoryRow(it, vm) { onOpen(it) } } }
    }
}
