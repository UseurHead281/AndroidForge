package com.mystories.player.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.mystories.player.App
import com.mystories.player.data.*
import com.mystories.player.service.PlaybackService
import com.mystories.player.service.StoryMedia
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PlayerState(val storyId: Long = 0, val playing: Boolean = false, val durationMs: Long = 0, val speed: Float = 1f)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as App
    private val repo = a.repo
    val settings = a.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val stories = repo.stories.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bookmarks = repo.bookmarks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sources = repo.sources.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sleep = a.sleep.state
    val sleepTimer get() = a.sleep
    val importer get() = a.importer
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val player = MutableStateFlow(PlayerState())
    val busy = MutableStateFlow(false)
    private var controller: MediaController? = null

    private val listener = object : Player.Listener {
        override fun onEvents(p: Player, events: Player.Events) = sync()
        override fun onPlayerError(error: PlaybackException) {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull()
            messages.tryEmit("Не удалось воспроизвести файл. Возможно, он перемещён, повреждён или формат не поддерживается.")
            if (id != null) viewModelScope.launch { if (!a.importer.isReachable(Uri.parse(repo.story(id)?.uri ?: return@launch))) a.repo.dao.setMissing(id, true) }
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            try { controller = f.get().also { it.addListener(listener) }; sync() } catch (e: Exception) { messages.tryEmit("Плеер недоступен") }
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch {
            val first = stories.first { it.isNotEmpty() }
            if (player.value.storyId == 0L) first.filter { it.lastPlayedAt > 0 }.maxByOrNull { it.lastPlayedAt }
                ?.let { s -> player.update { it.copy(storyId = s.id) } }
        }
    }

    private fun sync() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        player.update {
            it.copy(
                storyId = id ?: it.storyId, playing = c.isPlaying,
                durationMs = if (c.duration > 0) c.duration else it.durationMs, speed = c.playbackParameters.speed
            )
        }
    }

    fun <T> set(key: Preferences.Key<T>, v: T) { viewModelScope.launch { a.settings.set(key, v) } }
    fun resetAppearance() { viewModelScope.launch { a.settings.resetAppearance() } }
    fun say(m: String) { messages.tryEmit(m) }

    // ---------- воспроизведение ----------
    fun livePosition(id: Long): Long {
        val c = controller
        return if (c != null && c.currentMediaItem?.mediaId?.toLongOrNull() == id) c.currentPosition
        else stories.value.find { it.id == id }?.positionMs ?: 0
    }

    fun play(story: StoryEntity, startMs: Long? = null) {
        val c = controller ?: run { say("Плеер запускается, попробуйте ещё раз"); return }
        viewModelScope.launch {
            val s = repo.story(story.id) ?: return@launch
            val cfg = settings.value
            val curId = c.currentMediaItem?.mediaId?.toLongOrNull()
            val state = c.playbackState
            val loaded = curId == s.id && state != Player.STATE_IDLE && state != Player.STATE_ENDED
            if (loaded) { if (startMs != null) c.seekTo(startMs); c.play(); return@launch }
            if (curId != null && curId != s.id) repo.savePosition(curId, c.currentPosition)
            var start = startMs ?: s.positionMs
            if (startMs == null && (s.completed || (s.durationMs > 0 && start >= s.durationMs - 1500))) { start = 0; repo.setCompleted(s.id, false) }
            val speed = if (cfg.perStorySpeed && s.speed > 0f) s.speed else cfg.speed
            repo.incPlay(s.id)
            c.setMediaItem(StoryMedia.item(s), start.coerceAtLeast(0))
            c.playbackParameters = PlaybackParameters(speed)
            c.prepare(); c.play()
            player.update { it.copy(storyId = s.id) }
        }
    }

    fun togglePlay() {
        val c = controller ?: return
        val sel = stories.value.find { it.id == player.value.storyId } ?: return
        val curId = c.currentMediaItem?.mediaId?.toLongOrNull()
        if (curId == sel.id && c.playbackState != Player.STATE_IDLE && c.playbackState != Player.STATE_ENDED) {
            if (c.isPlaying) c.pause() else c.play()
        } else play(sel)
    }
    fun seekTo(story: StoryEntity, ms: Long) {
        val c = controller
        if (c != null && c.currentMediaItem?.mediaId?.toLongOrNull() == story.id) c.seekTo(ms)
        else viewModelScope.launch { repo.savePosition(story.id, ms) }
    }
    fun seekBy(story: StoryEntity, forward: Boolean) {
        val d = story.durationMs.takeIf { it > 0 } ?: Long.MAX_VALUE
        val delta = (if (forward) settings.value.seekFwd else -settings.value.seekBack) * 1000L
        seekTo(story, (livePosition(story.id) + delta).coerceIn(0, d))
    }
    fun skipSeries(story: StoryEntity, next: Boolean) {
        viewModelScope.launch {
            val n = repo.neighbor(story.id, next)
            if (n == null) say(if (next) "Следующей части нет" else "Предыдущей части нет") else play(n)
        }
    }
    fun setSpeed(story: StoryEntity, v: Float) {
        val sp = (Math.round(v * 20) / 20f).coerceIn(0.5f, 3f)
        controller?.playbackParameters = PlaybackParameters(sp)
        player.update { it.copy(speed = sp) }
        if (settings.value.perStorySpeed) viewModelScope.launch { repo.setSpeed(story.id, sp) } else set(K.speed, sp)
    }
    fun saveNow() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val pos = c.currentPosition
        a.appScope.launch { repo.savePosition(id, pos) }
    }

    // ---------- история ----------
    fun update(s: StoryEntity) { viewModelScope.launch { repo.update(s) } }
    fun toggleFavorite(s: StoryEntity) { viewModelScope.launch { repo.setFavorite(s.id, !s.favorite) } }
    fun setCompleted(s: StoryEntity, done: Boolean) { viewModelScope.launch { repo.setCompleted(s.id, done) } }
    fun restart(s: StoryEntity) {
        viewModelScope.launch { repo.savePosition(s.id, 0); repo.setCompleted(s.id, false); seekTo(s, 0) }
    }
    fun removeFromLibrary(s: StoryEntity) {
        viewModelScope.launch {
            if (player.value.storyId == s.id) { controller?.stop(); controller?.clearMediaItems(); player.update { PlayerState() } }
            repo.remove(s.id)
        }
    }
    fun deleteFile(s: StoryEntity) {
        viewModelScope.launch {
            if (a.importer.deleteFile(Uri.parse(s.uri))) { removeFromLibrary(s); say("Файл удалён") }
            else say("Не удалось удалить файл: нет прав на запись")
        }
    }
    fun renameFile(s: StoryEntity, name: String) {
        viewModelScope.launch {
            val n = a.importer.renameFile(Uri.parse(s.uri), name)
            if (n == null) say("Не удалось переименовать файл: нет прав на запись")
            else { repo.update(s.copy(uri = n.toString(), fileName = name)); say("Файл переименован") }
        }
    }
    fun relink(s: StoryEntity, uri: Uri) {
        viewModelScope.launch { say(if (a.importer.relink(s, uri)) "Файл найден заново, прогресс сохранён" else "Этот файл уже есть в библиотеке") }
    }
    fun setCover(s: StoryEntity, uri: Uri) {
        viewModelScope.launch { a.importer.saveCustomCover(s.id, uri)?.let { repo.update(s.copy(coverPath = it)) } }
    }
    fun renameAuthor(old: String, new: String) { viewModelScope.launch { repo.renameAuthor(old, new) } }

    // ---------- закладки ----------
    fun addBookmark(s: StoryEntity, pos: Long, color: Long, title: String? = null) {
        viewModelScope.launch { repo.addBookmark(BookmarkEntity(storyId = s.id, positionMs = pos, color = color, title = title ?: "Закладка ${fmt(pos)}")) }
    }
    fun updateBookmark(b: BookmarkEntity) { viewModelScope.launch { repo.updateBookmark(b) } }
    fun deleteBookmark(b: BookmarkEntity) { viewModelScope.launch { repo.deleteBookmark(b) } }

    // ---------- импорт и источники ----------
    private fun job(block: suspend () -> ImportResult) {
        viewModelScope.launch { busy.value = true; try { say(block().summary()) } finally { busy.value = false } }
    }
    fun importFiles(uris: List<Uri>) = job { a.importer.importFiles(uris) }
    fun addFolder(uri: Uri) = job { a.importer.addTree(uri) }
    fun rescan(src: SourceEntity) = job { a.importer.scan(src) }
    fun rescanAll() = job {
        var r = ImportResult()
        for (s in a.repo.dao.allSources()) { val x = a.importer.scan(s); r = ImportResult(r.added + x.added, r.duplicates + x.duplicates, r.failed + x.failed) }
        r
    }
    fun removeSource(src: SourceEntity) { viewModelScope.launch { a.repo.dao.detachSource(src.id); a.repo.dao.deleteSource(src.id) } }
    fun checkMissing() {
        viewModelScope.launch { busy.value = true; val n = a.importer.checkMissing(); busy.value = false; say(if (n == 0) "Все файлы доступны" else "Недоступных файлов: $n") }
    }
    fun resetStats() { viewModelScope.launch { repo.resetStats() } }
    fun listened(since: Long) = repo.listenedSince(since)
}
