package com.mystories.player.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class ImportResult(val added: Int = 0, val duplicates: Int = 0, val failed: Int = 0) {
    fun summary() = "Добавлено: $added, уже были: $duplicates, ошибок: $failed"
}

private data class Found(val uri: Uri, val name: String, val folder: String)

object NameParser {
    private val partRe = Regex("(?i)(?:часть|глава|part|chapter|ch|ep|эпизод|серия)[\\s._-]*(\\d{1,4})")
    private val leadRe = Regex("^\\s*(\\d{1,4})[\\s._-]")
    fun part(base: String): Int =
        partRe.find(base)?.groupValues?.get(1)?.toIntOrNull() ?: leadRe.find(base)?.groupValues?.get(1)?.toIntOrNull() ?: 0
}

class Importer(private val ctx: Context, private val dao: AppDao) {
    private val exts = setOf("mp3", "m4a", "m4b", "aac", "wav", "flac", "ogg", "oga", "opus")

    private fun isAudio(name: String, mime: String) =
        mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in exts

    suspend fun importFiles(uris: List<Uri>, sourceId: Long? = null, folder: String = ""): ImportResult =
        withContext(Dispatchers.IO) {
            var a = 0; var d = 0; var f = 0
            for (u in uris) {
                try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                when (addOne(u, null, sourceId, folder)) { 1 -> a++; 0 -> d++; else -> f++ }
            }
            ImportResult(a, d, f)
        }

    suspend fun addTree(tree: Uri): ImportResult = withContext(Dispatchers.IO) {
        try { ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val existing = dao.sourceByUri(tree.toString())
        val src = existing ?: SourceEntity(
            uri = tree.toString(), name = DocumentFile.fromTreeUri(ctx, tree)?.name ?: "Папка"
        ).let { it.copy(id = dao.insertSource(it)) }
        scan(src)
    }

    suspend fun scan(src: SourceEntity): ImportResult = withContext(Dispatchers.IO) {
        val tree = Uri.parse(src.uri)
        val found = mutableListOf<Found>()
        try { list(tree, DocumentsContract.getTreeDocumentId(tree), src.name, found) } catch (_: Exception) {}
        var a = 0; var d = 0; var f = 0
        for (x in found) when (addOne(x.uri, x.name, src.id, x.folder)) { 1 -> a++; 0 -> d++; else -> f++ }
        val foundSet = found.map { it.uri.toString() }.toSet()
        if (found.isNotEmpty()) for (s in dao.storiesBySource(src.id)) {
            val miss = s.uri !in foundSet
            if (s.missing != miss) dao.setMissing(s.id, miss)
        }
        dao.updateSource(src.copy(lastScan = System.currentTimeMillis(), fileCount = found.size))
        ImportResult(a, d, f)
    }

    private fun list(tree: Uri, docId: String, folder: String, out: MutableList<Found>) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) list(tree, id, name, out)
                else if (isAudio(name, mime)) out += Found(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, folder)
            }
        }
    }

    /** 1 — добавлено, 0 — дубликат, -1 — ошибка */
    private suspend fun addOne(uri: Uri, nameHint: String?, sourceId: Long?, folder: String): Int {
        if (dao.storyByUri(uri.toString()) != null) return 0
        val doc = try { DocumentFile.fromSingleUri(ctx, uri) } catch (_: Exception) { null }
        val fileName = nameHint ?: doc?.name ?: "audio"
        val base = fileName.substringBeforeLast('.')
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, uri)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (dur <= 0) return -1
            var title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
            var author = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST))?.takeIf { it.isNotBlank() }
            val album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.takeIf { it.isNotBlank() }
            val track = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)
                ?.substringBefore('/')?.trim()?.toIntOrNull()
            if (title == null && author == null && " - " in base) {
                author = base.substringBefore(" - ").trim(); title = base.substringAfter(" - ").trim()
            }
            val cover = mmr.embeddedPicture?.let { saveCover(it, "emb_${uri.hashCode()}") }
            val story = StoryEntity(
                title = title ?: base, author = author ?: "", series = album ?: "",
                partNumber = track ?: NameParser.part(base), uri = uri.toString(), fileName = fileName,
                sourceId = sourceId, folderName = folder, coverPath = cover, durationMs = dur,
                sizeBytes = doc?.length() ?: 0
            )
            if (dao.insertStory(story) == -1L) 0 else 1
        } catch (_: Exception) { -1 } finally { try { mmr.release() } catch (_: Exception) {} }
    }

    private fun saveCover(bytes: ByteArray, name: String): String? = try {
        val dir = File(ctx.filesDir, "covers").apply { mkdirs() }
        File(dir, "$name.jpg").also { it.writeBytes(bytes) }.absolutePath
    } catch (_: Exception) { null }

    suspend fun saveCustomCover(storyId: Long, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@withContext null
            saveCover(bytes, "custom_${storyId}_${System.currentTimeMillis()}")
        } catch (_: Exception) { null }
    }

    suspend fun isReachable(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { true } ?: false } catch (_: Exception) { false }
    }

    suspend fun checkMissing(): Int = withContext(Dispatchers.IO) {
        var n = 0
        for (s in dao.allStories()) {
            val miss = !isReachable(Uri.parse(s.uri))
            if (miss) n++
            if (miss != s.missing) dao.setMissing(s.id, miss)
        }
        n
    }

    suspend fun renameFile(uri: Uri, newName: String): Uri? = withContext(Dispatchers.IO) {
        try { DocumentsContract.renameDocument(ctx.contentResolver, uri, newName) } catch (_: Exception) { null }
    }

    suspend fun deleteFile(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try { DocumentsContract.deleteDocument(ctx.contentResolver, uri) } catch (_: Exception) { false }
    }

    fun hasPermission(uri: String): Boolean =
        ctx.contentResolver.persistedUriPermissions.any { it.uri.toString() == uri && it.isReadPermission }

    suspend fun relink(story: StoryEntity, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        if (dao.storyByUri(uri.toString()) != null) return@withContext false
        val name = DocumentFile.fromSingleUri(ctx, uri)?.name ?: story.fileName
        dao.updateStory(story.copy(uri = uri.toString(), fileName = name, missing = false, sourceId = null))
        true
    }
}
