package com.mystories.player.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.mystories.player.data.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

fun fmt(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0); val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
fun fmtDur(sec: Long): String { val h = sec / 3600; val m = (sec % 3600) / 60; return if (h > 0) "$h ч $m мин" else "$m мин" }
fun fmtDate(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(ms))
fun fmtSize(b: Long): String = if (b <= 0) "—" else "%.1f МБ".format(b / 1048576.0)

@Composable
fun Cover(s: StoryEntity?, modifier: Modifier = Modifier) {
    val seed = s?.title ?: ""
    val hue = (abs(seed.hashCode()) % 360).toFloat()
    Box(
        modifier.clip(MaterialTheme.shapes.large).background(
            Brush.linearGradient(listOf(Color.hsv(hue, 0.55f, 0.6f), Color.hsv((hue + 40) % 360, 0.6f, 0.35f)))
        ), contentAlignment = Alignment.Center
    ) {
        if (s?.coverPath != null) AsyncImage(File(s.coverPath), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(seed.take(1).uppercase(), style = MaterialTheme.typography.displaySmall, color = Color.White)
    }
}

@Composable
fun Equalizer(active: Boolean, color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(modifier.height(18.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        repeat(4) { i ->
            val h = if (active) t.animateFloat(
                0.25f, 1f, infiniteRepeatable(tween(450 + i * 130), RepeatMode.Reverse), label = "b$i"
            ).value else 0.25f
            Box(Modifier.width(4.dp).fillMaxHeight(h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

@Composable
fun EmptyState(title: String, text: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(text, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) Button(onClick = onAction) { Text(action) }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) =
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp))

@Composable
fun StoryTile(s: StoryEntity, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.width(140.dp).clip(MaterialTheme.shapes.medium).clickable(onClick = onClick).padding(4.dp)) {
        Cover(s, Modifier.size(132.dp))
        Spacer(Modifier.height(6.dp))
        Text(s.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge)
        Text(s.author.ifBlank { "Без автора" }, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (s.percent() > 0) LinearProgressIndicator(progress = { s.percent() / 100f }, Modifier.fillMaxWidth().padding(top = 4.dp))
    }
}

@Composable
fun StoryRow(s: StoryEntity, vm: MainViewModel, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cover(s, Modifier.size(60.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            val sub = listOfNotNull(s.author.takeIf { it.isNotBlank() }, s.series.takeIf { it.isNotBlank() }?.let { it + if (s.partNumber > 0) " · ч. ${s.partNumber}" else "" }).joinToString(" • ")
            if (sub.isNotBlank()) Text(sub, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                (if (s.missing) "Файл не найден • " else "") + "${fmt(s.durationMs)} • ${s.status()}",
                style = MaterialTheme.typography.labelSmall,
                color = if (s.missing) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (s.percent() > 0) LinearProgressIndicator(progress = { s.percent() / 100f }, Modifier.fillMaxWidth().padding(top = 4.dp))
        }
        if (s.favorite) Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        StoryMenuButton(s, vm)
    }
}

@Composable
fun TextDialog(title: String, initial: String, label: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton({ if (v.isNotBlank()) onOk(v.trim()) }) { Text("Сохранить") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, ok: String = "Да", onOk: () -> Unit, onDismiss: () -> Unit) =
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton({ onOk(); onDismiss() }) { Text(ok) } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )

val QuickColors = listOf(0xFFE53935L to "Важное", 0xFFFDD835L to "Интересное", 0xFF1E88E5L to "Заметка", 0xFF43A047L to "Любимое")

@Composable
fun ColorPickerRow(selected: Long, onSelect: (Long) -> Unit) {
    var hex by remember { mutableStateOf("") }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickColors.forEach { (c, _) ->
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(50)).background(Color(c))
                    .then(if (c == selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(50)) else Modifier)
                    .clickable { onSelect(c) })
            }
        }
        OutlinedTextField(hex, {
            hex = it.take(6)
            if (hex.length == 6) hex.toLongOrNull(16)?.let { v -> onSelect(0xFF000000L or v) }
        }, label = { Text("Свой цвет (RRGGBB)") }, singleLine = true, modifier = Modifier.padding(top = 8.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii))
    }
}

@Composable
fun BookmarkDialog(b: BookmarkEntity, onSave: (BookmarkEntity) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(b.title) }
    var note by remember { mutableStateOf(b.note) }
    var color by remember { mutableStateOf(b.color) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Закладка · ${fmt(b.positionMs)}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Заметка") })
                ColorPickerRow(color) { color = it }
            }
        },
        confirmButton = { TextButton({ onSave(b.copy(title = title.ifBlank { "Закладка" }, note = note, color = color)); onDismiss() }) { Text("Сохранить") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}
