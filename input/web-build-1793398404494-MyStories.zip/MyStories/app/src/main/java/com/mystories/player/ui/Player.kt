@file:OptIn(ExperimentalMaterial3Api::class)
package com.mystories.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.mystories.player.data.*
import kotlinx.coroutines.delay

@Composable
fun MiniPlayer(vm: MainViewModel, onExpand: () -> Unit) {
    val st by vm.player.collectAsState()
    val stories by vm.stories.collectAsState()
    val story = stories.find { it.id == st.storyId } ?: return
    Surface(Modifier.fillMaxWidth().padding(8.dp, 4.dp).clickable(onClick = onExpand), shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.secondaryContainer, tonalElevation = 3.dp) {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(story, Modifier.size(44.dp))
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(story.title, maxLines = 1, style = MaterialTheme.typography.titleSmall)
                    Text(story.author.ifBlank { fmt(story.durationMs) }, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                }
                IconButton({ vm.togglePlay() }) { Icon(if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (st.playing) "Пауза" else "Играть") }
            }
            var pos by remember(story.id) { mutableLongStateOf(vm.livePosition(story.id)) }
            val lc = LocalLifecycleOwner.current.lifecycle
            LaunchedEffect(story.id, st.playing) {
                lc.repeatOnLifecycle(Lifecycle.State.STARTED) { do { pos = vm.livePosition(story.id); delay(1000) } while (st.playing) }
            }
            LinearProgressIndicator({ if (story.durationMs > 0) (pos.toFloat() / story.durationMs).coerceIn(0f, 1f) else 0f }, Modifier.fillMaxWidth().height(3.dp))
        }
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel, onClose: () -> Unit) {
    val st by vm.player.collectAsState()
    val stories by vm.stories.collectAsState()
    val cfg by vm.settings.collectAsState()
    val allBms by vm.bookmarks.collectAsState()
    val sleep by vm.sleep.collectAsState()
    val story = stories.find { it.id == st.storyId }
    if (story == null) { Box(Modifier.fillMaxSize()); return }
    val bms = allBms.filter { it.storyId == story.id }
    val dur = story.durationMs.takeIf { it > 0 } ?: st.durationMs
    val hf = LocalHapticFeedback.current
    fun buzz() { if (cfg.haptics) hf.performHapticFeedback(HapticFeedbackType.LongPress) }

    var pos by remember(story.id) { mutableLongStateOf(vm.livePosition(story.id)) }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableLongStateOf(0L) }
    val lc = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(story.id, st.playing) {
        lc.repeatOnLifecycle(Lifecycle.State.STARTED) { do { if (!dragging) pos = vm.livePosition(story.id); delay(250) } while (st.playing) }
    }
    val view = LocalView.current
    DisposableEffect(st.playing, cfg.keepScreenOnPlayer) {
        view.keepScreenOn = st.playing && cfg.keepScreenOnPlayer
        onDispose { view.keepScreenOn = false }
    }

    var tab by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    var editBm by remember { mutableStateOf<BookmarkEntity?>(null) }
    editBm?.let { BookmarkDialog(it, { b -> vm.updateBookmark(b) }, { editBm = null }) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.saveNow(); onClose() }) { Icon(Icons.Rounded.KeyboardArrowDown, "Свернуть") }
                Text("Сейчас играет", Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
                StoryMenuButton(story, vm)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Обложка", "О истории", "Заметки").forEachIndexed { i, n -> FilterChip(tab == i, { tab = i }, label = { Text(n) }) }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                AnimatedContent(tab, label = "tab") { t ->
                    when (t) {
                        0 -> Box(contentAlignment = Alignment.BottomEnd) {
                            Cover(story, Modifier.fillMaxWidth().aspectRatio(1f))
                            if (cfg.visualizer && !cfg.reduceAnim) Equalizer(st.playing, Color.White, Modifier.padding(14.dp))
                        }
                        1 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Серия" to story.series.ifBlank { "—" }, "Часть" to if (story.partNumber > 0) story.partNumber.toString() else "—",
                                "Теги" to story.tags.ifBlank { "—" }, "Статус" to story.status(), "Прогресс" to "%.0f%%".format(story.percent()),
                                "Прослушано" to fmtDur(story.listenedSec), "Файл" to story.fileName).forEach { (k, v) ->
                                Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(v)
                            }
                            if (story.description.isNotBlank()) Text(story.description, style = MaterialTheme.typography.bodyMedium)
                        }
                        else -> {
                            var note by remember(story.id) { mutableStateOf(story.description) }
                            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Заметки к истории") },
                                    placeholder = { Text("Текст истории не добавлен. Запишите свои заметки здесь.") })
                                Button({ vm.update(story.copy(description = note)); vm.say("Заметка сохранена") }) { Text("Сохранить") }
                            }
                        }
                    }
                }
            }
            Text(story.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
            Text(listOf(story.author, story.series.takeIf { it.isNotBlank() }?.let { it + if (story.partNumber > 0) " · ч. ${story.partNumber}" else "" })
                .filter { !it.isNullOrBlank() }.joinToString(" • "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)

            val shown = if (dragging) dragPos else pos
            Box(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Slider(shown.toFloat(), { dragging = true; dragPos = it.toLong() },
                    onValueChangeFinished = { vm.seekTo(story, dragPos); pos = dragPos; dragging = false; buzz() },
                    valueRange = 0f..maxOf(dur, 1L).toFloat())
                val markerColors = bms.map { it.positionMs to it.color }
                Canvas(Modifier.matchParentSize()) {
                    val inset = 10.dp.toPx()
                    markerColors.forEach { (p, c) ->
                        val x = inset + (p.toFloat() / maxOf(dur, 1L)) * (size.width - 2 * inset)
                        drawCircle(Color(c), 4.dp.toPx(), Offset(x, 4.dp.toPx()))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(shown), color = if (dragging) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (dragging) FontWeight.Bold else FontWeight.Normal)
                Text("-" + fmt((dur - shown).coerceAtLeast(0)))
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.skipSeries(story, false) }) { Icon(Icons.Rounded.SkipPrevious, "Предыдущая часть") }
                IconButton({ vm.seekBy(story, false); buzz() }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Rounded.FastRewind, "Назад"); Text("${cfg.seekBack}", style = MaterialTheme.typography.labelSmall) }
                }
                FilledIconButton({ vm.togglePlay(); buzz() }, Modifier.size(72.dp)) {
                    Icon(if (st.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (st.playing) "Пауза" else "Играть", Modifier.size(40.dp))
                }
                IconButton({ vm.seekBy(story, true); buzz() }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Rounded.FastForward, "Вперёд"); Text("${cfg.seekFwd}", style = MaterialTheme.typography.labelSmall) }
                }
                IconButton({ vm.skipSeries(story, true) }) { Icon(Icons.Rounded.SkipNext, "Следующая часть") }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                AssistChip({ dlg = "speed" }, { Text("%.2fx".format(st.speed).replace(".00x", "x")) }, leadingIcon = { Icon(Icons.Rounded.Speed, null, Modifier.size(18.dp)) })
                AssistChip({ dlg = "sleep" }, { Text(if (sleep.endOfStory) "Конец" else if (sleep.remainingMs > 0) fmt(sleep.remainingMs) else "Сон") }, leadingIcon = { Icon(Icons.Rounded.Bedtime, null, Modifier.size(18.dp)) })
                AssistChip({ dlg = "bm" }, { Text("Закладки ${bms.size}") }, leadingIcon = { Icon(Icons.Rounded.Flag, null, Modifier.size(18.dp)) })
                IconButton({ vm.toggleFavorite(story); buzz() }) { Icon(if (story.favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Избранное") }
            }
        }
    }

    if (dlg == "speed") AlertDialog({ dlg = "" }, title = { Text("Скорость: %.2fx".format(st.speed)) }, text = {
        Column {
            Slider(st.speed, { vm.setSpeed(story, it) }, valueRange = 0.5f..3f, steps = 49)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v -> AssistChip({ vm.setSpeed(story, v) }, { Text("${v}x") }) }
            }
            Text(if (cfg.perStorySpeed) "Скорость запоминается для этой истории." else "Скорость общая для всех историй.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }
    }, confirmButton = { TextButton({ dlg = "" }) { Text("Готово") } })

    if (dlg == "sleep") AlertDialog({ dlg = "" }, title = { Text("Таймер сна") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (sleep.active) Text(if (sleep.endOfStory) "Остановка в конце истории" else "Осталось ${fmt(sleep.remainingMs)}", style = MaterialTheme.typography.titleMedium)
            listOf(5, 10, 15, 30, 45, 60).chunked(3).forEach { r ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { r.forEach { m -> FilledTonalButton({ vm.sleepTimer.startMinutes(m); dlg = "" }) { Text("$m мин") } } }
            }
            OutlinedButton({ vm.sleepTimer.endOfStory(); dlg = "" }) { Text("До конца истории") }
            if (sleep.remainingMs > 0) OutlinedButton({ vm.sleepTimer.addMinutes(5) }) { Text("+5 минут") }
            if (sleep.active) TextButton({ vm.sleepTimer.cancel(); dlg = "" }) { Text("Отменить таймер") }
        }
    }, confirmButton = { TextButton({ dlg = "" }) { Text("Закрыть") } })

    if (dlg == "bm") ModalBottomSheet({ dlg = "" }) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Text("Флажок на ${fmt(vm.livePosition(story.id))}", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickColors.forEach { (c, n) -> AssistChip({ vm.addBookmark(story, vm.livePosition(story.id), c, null); buzz() }, { Text(n) }, leadingIcon = { Icon(Icons.Rounded.Flag, null, tint = Color(c)) }) }
            }
            if (bms.isEmpty()) Text("Закладок пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
            bms.forEach { b ->
                Row(Modifier.fillMaxWidth().clickable { vm.seekTo(story, b.positionMs); if (!st.playing) vm.play(story, b.positionMs); dlg = "" }, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Flag, null, tint = Color(b.color))
                    Column(Modifier.weight(1f).padding(8.dp)) { Text(b.title); Text(fmt(b.positionMs) + if (b.note.isNotBlank()) " · ${b.note}" else "", style = MaterialTheme.typography.bodySmall) }
                    IconButton({ editBm = b }) { Icon(Icons.Rounded.Edit, "Изменить") }
                    IconButton({ vm.deleteBookmark(b) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                }
            }
        }
    }
}
