package com.mystories.player.ui

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.mystories.player.data.AppSettings

fun resolveDark(s: AppSettings, system: Boolean) = when (s.themeMode) { 1 -> false; 2 -> true; else -> system }

@Composable
fun AppTheme(s: AppSettings, content: @Composable () -> Unit) {
    val dark = resolveDark(s, androidx.compose.foundation.isSystemInDarkTheme())
    val ctx = LocalContext.current
    val accent = Color(s.accent)
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    val base = when {
        s.dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = accent, onPrimary = onAccent)
        else -> lightColorScheme(primary = accent, onPrimary = onAccent)
    }
    val scheme = if (dark && s.amoled) base.copy(
        background = Color.Black, surface = Color.Black, surfaceContainerLowest = Color.Black,
        surfaceContainerLow = Color.Black, surfaceContainer = Color(0xFF0A0A0A),
        surfaceContainerHigh = Color(0xFF121212), surfaceContainerHighest = Color(0xFF1A1A1A),
        surfaceVariant = Color(0xFF121212)
    ) else base
    val r = s.cornerRadius.dp
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(r / 4), small = RoundedCornerShape(r / 2),
        medium = RoundedCornerShape(r * 0.7f), large = RoundedCornerShape(r), extraLarge = RoundedCornerShape(r * 1.4f)
    )
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * s.fontScale)) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, content = content)
    }
}
