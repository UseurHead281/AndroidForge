package com.mystories.player.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.*

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

data class AppSettings(
    val themeMode: Int = 0,            // 0 системная, 1 светлая, 2 тёмная
    val amoled: Boolean = false,
    val dynamic: Boolean = true,
    val accent: Long = 0xFF6750A4,
    val cornerRadius: Int = 24,
    val fontScale: Float = 1f,
    val reduceAnim: Boolean = false,
    val haptics: Boolean = true,
    val visualizer: Boolean = true,
    val seekBack: Int = 15,
    val seekFwd: Int = 30,
    val speed: Float = 1f,
    val perStorySpeed: Boolean = true,
    val autoNext: Boolean = true,
    val pauseOnUnplug: Boolean = true,
    val keepScreenOnPlayer: Boolean = true,
    val fadeSec: Int = 10,
    val libView: Int = 0,              // 0 сетка, 1 список
    val libSort: Int = 2,
    val libGroup: Int = 0
)

object K {
    val theme = intPreferencesKey("theme")
    val amoled = booleanPreferencesKey("amoled")
    val dynamic = booleanPreferencesKey("dynamic")
    val accent = longPreferencesKey("accent")
    val radius = intPreferencesKey("radius")
    val fontScale = floatPreferencesKey("fontScale")
    val reduceAnim = booleanPreferencesKey("reduceAnim")
    val haptics = booleanPreferencesKey("haptics")
    val visualizer = booleanPreferencesKey("visualizer")
    val seekBack = intPreferencesKey("seekBack")
    val seekFwd = intPreferencesKey("seekFwd")
    val speed = floatPreferencesKey("speed")
    val perStory = booleanPreferencesKey("perStory")
    val autoNext = booleanPreferencesKey("autoNext")
    val unplug = booleanPreferencesKey("unplug")
    val keepOn = booleanPreferencesKey("keepOn")
    val fade = intPreferencesKey("fade")
    val libView = intPreferencesKey("libView")
    val libSort = intPreferencesKey("libSort")
    val libGroup = intPreferencesKey("libGroup")
}

class SettingsStore(private val ctx: Context) {
    private val d = AppSettings()
    val flow: Flow<AppSettings> = ctx.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            AppSettings(
                themeMode = p[K.theme] ?: d.themeMode, amoled = p[K.amoled] ?: d.amoled,
                dynamic = p[K.dynamic] ?: d.dynamic, accent = p[K.accent] ?: d.accent,
                cornerRadius = p[K.radius] ?: d.cornerRadius, fontScale = p[K.fontScale] ?: d.fontScale,
                reduceAnim = p[K.reduceAnim] ?: d.reduceAnim, haptics = p[K.haptics] ?: d.haptics,
                visualizer = p[K.visualizer] ?: d.visualizer, seekBack = p[K.seekBack] ?: d.seekBack,
                seekFwd = p[K.seekFwd] ?: d.seekFwd, speed = p[K.speed] ?: d.speed,
                perStorySpeed = p[K.perStory] ?: d.perStorySpeed, autoNext = p[K.autoNext] ?: d.autoNext,
                pauseOnUnplug = p[K.unplug] ?: d.pauseOnUnplug, keepScreenOnPlayer = p[K.keepOn] ?: d.keepScreenOnPlayer,
                fadeSec = p[K.fade] ?: d.fadeSec, libView = p[K.libView] ?: d.libView,
                libSort = p[K.libSort] ?: d.libSort, libGroup = p[K.libGroup] ?: d.libGroup
            )
        }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) { ctx.dataStore.edit { it[key] = value } }

    suspend fun resetAppearance() {
        ctx.dataStore.edit {
            it.remove(K.theme); it.remove(K.amoled); it.remove(K.dynamic); it.remove(K.accent)
            it.remove(K.radius); it.remove(K.fontScale); it.remove(K.reduceAnim); it.remove(K.visualizer)
        }
    }
}
