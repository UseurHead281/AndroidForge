package com.mystories.player.service

import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.mystories.player.App
import com.mystories.player.data.AppSettings
import com.mystories.player.data.StoryEntity
import kotlinx.coroutines.*
import java.io.File

object StoryMedia {
    fun item(s: StoryEntity): MediaItem = MediaItem.Builder()
        .setMediaId(s.id.toString())
        .setUri(s.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(s.title)
                .setArtist(s.author.ifBlank { null })
                .setAlbumTitle(s.series.ifBlank { null })
                .setArtworkUri(s.coverPath?.let { Uri.fromFile(File(it)) })
                .build()
        ).build()
}

class PlaybackService : MediaSessionService() {
    private lateinit var app: App
    private lateinit var exo: ExoPlayer
    private var session: MediaSession? = null
    @Volatile private var cfg = AppSettings()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tick: Job? = null
    private var playingSince = 0L
    private var pendingMs = 0L
    private var trackedId = 0L

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            val now = SystemClock.elapsedRealtime()
            if (isPlaying) {
                playingSince = now
                tick?.cancel()
                tick = scope.launch { while (true) { delay(5000); accumulate(); commit() } }
            } else {
                if (playingSince != 0L) pendingMs += now - playingSince
                playingSince = 0
                tick?.cancel()
                commit()
            }
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            accumulate()
            val old = trackedId
            val sec = takeSeconds()
            if (old > 0 && sec > 0) app.appScope.launch { app.repo.addListen(old, sec) }
            trackedId = mediaItem?.mediaId?.toLongOrNull() ?: 0
        }
        override fun onPositionDiscontinuity(o: Player.PositionInfo, n: Player.PositionInfo, reason: Int) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK && !exo.isPlaying) commit()
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) onEnded()
        }
    }

    private fun accumulate() {
        if (playingSince != 0L) {
            val now = SystemClock.elapsedRealtime(); pendingMs += now - playingSince; playingSince = now
        }
    }
    private fun takeSeconds(): Long { val s = pendingMs / 1000; pendingMs -= s * 1000; return s }

    /** Сохраняет позицию и накопленное время прослушивания. */
    private fun commit() {
        val id = trackedId
        val sec = takeSeconds()
        val pos = exo.currentPosition
        val cur = exo.currentMediaItem?.mediaId?.toLongOrNull()
        if (id <= 0) return
        app.appScope.launch {
            if (sec > 0) app.repo.addListen(id, sec)
            if (cur == id) app.repo.savePosition(id, pos)
        }
    }

    private fun onEnded() {
        val id = trackedId
        accumulate(); commit()
        if (id <= 0) return
        val dur = exo.duration
        app.appScope.launch {
            app.repo.markEnded(id, dur)
            if (app.sleep.state.value.endOfStory) { app.sleep.finish(); return@launch }
            if (cfg.autoNext) app.repo.neighbor(id, true)?.let { if (!it.missing) startStory(it) }
        }
    }

    private suspend fun startStory(s: StoryEntity) {
        exo.setMediaItem(StoryMedia.item(s), if (s.completed) 0 else s.positionMs)
        exo.playbackParameters = PlaybackParameters(if (cfg.perStorySpeed && s.speed > 0f) s.speed else cfg.speed)
        exo.prepare(); exo.play()
        app.repo.setCompleted(s.id, false)
        app.repo.incPlay(s.id)
    }

    override fun onCreate() {
        super.onCreate()
        app = application as App
        exo = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        exo.addListener(listener)
        app.sleep.player = exo
        // Перемотка из уведомления/гарнитуры использует значения из настроек.
        val wrapped = object : ForwardingPlayer(exo) {
            override fun getSeekBackIncrement() = cfg.seekBack * 1000L
            override fun getSeekForwardIncrement() = cfg.seekFwd * 1000L
            override fun seekBack() { wrappedPlayer.seekTo((wrappedPlayer.currentPosition - seekBackIncrement).coerceAtLeast(0)) }
            override fun seekForward() {
                val d = wrappedPlayer.duration
                val t = wrappedPlayer.currentPosition + seekForwardIncrement
                wrappedPlayer.seekTo(if (d != C.TIME_UNSET) t.coerceAtMost(d) else t)
            }
        }
        session = MediaSession.Builder(this, wrapped).build()
        scope.launch {
            app.settings.flow.collect {
                cfg = it
                exo.setHandleAudioBecomingNoisy(it.pauseOnUnplug)
                app.sleep.fadeSec = it.fadeSec
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        accumulate(); commit()
        if (!exo.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        accumulate(); commit()
        scope.cancel()
        app.sleep.player = null
        session?.release(); session = null
        exo.release()
        super.onDestroy()
    }
}
