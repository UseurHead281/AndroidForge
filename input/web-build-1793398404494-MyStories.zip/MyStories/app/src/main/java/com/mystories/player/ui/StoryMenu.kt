package com.mystories.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mystories.player.data.StoryEntity

@Composable
fun StoryMenuButton(s: StoryEntity, vm: MainViewModel) {
    var menu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }
    Box {
        IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Меню") }
        DropdownMenu(menu, { menu = false }) {
            fun item(text: String, key: String = "", action: () -> Unit = {}) =
                DropdownMenuItem(text = { Text(text) }, onClick = { menu = false; if (key.isNotEmpty()) dlg = key; action() })
            item(if (s.favorite) "Убрать из избранного" else "В избранное") { vm.toggleFavorite(s) }
            item("Редактировать", "edit")
            item(if (s.completed) "Вернуть «В процессе»" else "Отметить завершённой") { vm.setCompleted(s, !s.completed) }
            item("Начать сначала", "restart")
            item("Информация о файле", "info")
            item("Переименовать файл…", "rename")
            item("Удалить из библиотеки", "remove")
            item("Удалить файл с устройства…", "delete")
        }
    }
    val close = { dlg = "" }
    when (dlg) {
        "edit" -> EditDialog(s, vm, close)
        "info" -> InfoDialog(s, vm, close)
        "restart" -> ConfirmDialog("Начать сначала?", "Позиция прослушивания будет сброшена на 0:00.", "Сбросить", { vm.restart(s) }, close)
        "remove" -> ConfirmDialog("Удалить из библиотеки?", "Файл на устройстве останется нетронутым. Закладки этой истории будут удалены.", "Удалить", { vm.removeFromLibrary(s) }, close)
        "delete" -> ConfirmDialog("Удалить файл физически?", "Файл «${s.fileName}» будет удалён с устройства без возможности восстановления.", "Удалить файл", { vm.deleteFile(s) }, close)
        "rename" -> TextDialog("Переименовать файл", s.fileName, "Имя файла (с расширением)", { vm.renameFile(s, it); close() }, close)
    }
}

@Composable
private fun EditDialog(s: StoryEntity, vm: MainViewModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(s.title) }
    var author by remember { mutableStateOf(s.author) }
    var series by remember { mutableStateOf(s.series) }
    var part by remember { mutableStateOf(if (s.partNumber > 0) s.partNumber.toString() else "") }
    var tags by remember { mutableStateOf(s.tags) }
    var desc by remember { mutableStateOf(s.description) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.setCover(s, u) } }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Редактировать") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("Автор") }, singleLine = true)
                OutlinedTextField(series, { series = it }, label = { Text("Серия") }, singleLine = true)
                OutlinedTextField(part, { part = it.filter(Char::isDigit).take(4) }, label = { Text("Номер части") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(tags, { tags = it }, label = { Text("Жанры и теги (через запятую)") })
                OutlinedTextField(desc, { desc = it }, label = { Text("Описание") })
                OutlinedButton({ pick.launch("image/*") }) { Icon(Icons.Rounded.Image, null); Spacer(Modifier.width(8.dp)); Text("Выбрать обложку") }
                Text("Изменение названия не переименовывает файл на устройстве.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton({
                vm.update(s.copy(title = title.ifBlank { s.title }, author = author.trim(), series = series.trim(),
                    partNumber = part.toIntOrNull() ?: 0, tags = tags.trim(), description = desc))
                onDismiss()
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun InfoDialog(s: StoryEntity, vm: MainViewModel, onDismiss: () -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> vm.relink(s, u) } }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("О файле") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(
                    "Имя файла" to s.fileName, "Папка" to s.folderName.ifBlank { "Добавлен вручную" },
                    "URI" to s.uri, "Размер" to fmtSize(s.sizeBytes), "Длительность" to fmt(s.durationMs),
                    "Добавлено" to fmtDate(s.addedAt), "Последнее прослушивание" to fmtDate(s.lastPlayedAt),
                    "Запусков" to s.playCount.toString(), "Прослушано" to fmtDur(s.listenedSec),
                    "Доступ" to if (s.missing) "Файл недоступен" else "OK"
                ).forEach { (k, v) -> Text(k, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text(v, style = MaterialTheme.typography.bodyMedium) }
                if (s.missing) Button({ pick.launch(arrayOf("audio/*", "application/ogg")) }) { Text("Найти файл заново") }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Закрыть") } }
    )
}
