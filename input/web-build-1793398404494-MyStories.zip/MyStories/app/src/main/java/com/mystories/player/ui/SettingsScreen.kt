@file:OptIn(ExperimentalMaterial3Api::class)
package com.mystories.player.ui

import android.os.Build
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mystories.player.data.*
import java.util.Calendar

private val LocalQuery = compositionLocalOf { "" }

@Composable
private fun Item(title: String, desc: String = "", content: @Composable ColumnScope.() -> Unit) {
    val q = LocalQuery.current
    if (q.isNotBlank() && !title.contains(q, true) && !desc.contains(q, true)) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        if (desc.isNotBlank()) Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
private fun SwitchItem(title: String, desc: String, value: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val q = LocalQuery.current
    if (q.isNotBlank() && !title.contains(q, true) && !desc.contains(q, true)) return
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(value, onChange, enabled = enabled)
    }
}

@Composable
private fun Chips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEachIndexed { i, o -> FilterChip(selected == i, { onSelect(i) }, label = { Text(o) }) }
    }

@Composable
private fun Header(text: String) {
    if (LocalQuery.current.isBlank()) Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 20.dp, 16.dp, 4.dp))
}

private val accents = listOf(0xFF6750A4L, 0xFFB3261EL, 0xFFE65100L, 0xFF2E7D32L, 0xFF00796BL, 0xFF1565C0L, 0xFFAD1457L, 0xFF455A64L)
private val seekOptions = listOf(5, 10, 15, 30, 60)

@Composable
fun SettingsScreen(vm: MainViewModel, onAddFiles: () -> Unit, onAddFolder: () -> Unit) {
    val s by vm.settings.collectAsState()
    val sources by vm.sources.collectAsState()
    val stories by vm.stories.collectAsState()
    val busy by vm.busy.collectAsState()
    var query by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    if (confirmReset) ConfirmDialog("Сбросить статистику?", "Время прослушивания и количество запусков будут обнулены. Позиции и закладки останутся.", "Сбросить", { vm.resetStats() }, { confirmReset = false })

    CompositionLocalProvider(LocalQuery provides query) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                Text("Настройки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 24.dp, 16.dp, 8.dp))
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, shape = RoundedCornerShape(28.dp),
                    leadingIcon = { Icon(Icons.Rounded.Search, null) }, placeholder = { Text("Поиск по настройкам") })
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp))
            }
            item {
                Header("Внешний вид")
                Item("Тема") { Chips(listOf("Системная", "Светлая", "Тёмная"), s.themeMode) { vm.set(K.theme, it) } }
                SwitchItem("Чёрная AMOLED-тема", "Настоящий #000000 на фонах в тёмной теме", s.amoled) { vm.set(K.amoled, it) }
                SwitchItem("Динамические цвета", if (Build.VERSION.SDK_INT >= 31) "Цвета из обоев (Android 12+)" else "Недоступно на этой версии Android", s.dynamic, Build.VERSION.SDK_INT >= 31) { vm.set(K.dynamic, it) }
                Item("Основной цвет", "Работает при выключенных динамических цветах") {
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        accents.forEach { c ->
                            Box(Modifier.size(36.dp).clip(RoundedCornerShape(50)).background(Color(c))
                                .then(if (c == s.accent) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(50)) else Modifier)
                                .clickable { vm.set(K.accent, c) })
                        }
                    }
                }
                Item("Радиус скругления: ${s.cornerRadius} dp") { Slider(s.cornerRadius.toFloat(), { vm.set(K.radius, it.toInt()) }, valueRange = 4f..40f) }
                Item("Размер текста: ${(s.fontScale * 100).toInt()}%") { Slider(s.fontScale, { vm.set(K.fontScale, Math.round(it * 20) / 20f) }, valueRange = 0.8f..1.4f, steps = 11) }
                SwitchItem("Сократить анимации", "Отключает декоративные эффекты", s.reduceAnim) { vm.set(K.reduceAnim, it) }
                SwitchItem("Эквалайзер на обложке", "Анимация во время воспроизведения", s.visualizer) { vm.set(K.visualizer, it) }
                SwitchItem("Тактильная отдача", "Вибрация при важных действиях", s.haptics) { vm.set(K.haptics, it) }
                Item("") { TextButton({ vm.resetAppearance() }) { Text("Вернуть стандартное оформление") } }
            }
            item {
                Header("Проигрыватель")
                Item("Перемотка назад, сек") { Chips(seekOptions.map { "$it" }, seekOptions.indexOf(s.seekBack)) { vm.set(K.seekBack, seekOptions[it]) } }
                Item("Перемотка вперёд, сек") { Chips(seekOptions.map { "$it" }, seekOptions.indexOf(s.seekFwd)) { vm.set(K.seekFwd, seekOptions[it]) } }
                Item("Скорость по умолчанию: %.2fx".format(s.speed), "От 0,5x до 3,0x") { Slider(s.speed, { vm.set(K.speed, Math.round(it * 20) / 20f) }, valueRange = 0.5f..3f, steps = 49) }
                SwitchItem("Скорость для каждой истории", "Иначе одна скорость для всех", s.perStorySpeed) { vm.set(K.perStory, it) }
                SwitchItem("Автопереход к следующей части", "После конца части той же серии", s.autoNext) { vm.set(K.autoNext, it) }
                SwitchItem("Пауза при отключении наушников", "Защита от неожиданного звука", s.pauseOnUnplug) { vm.set(K.unplug, it) }
                SwitchItem("Не гасить экран в плеере", "Только пока открыт плеер и идёт звук", s.keepScreenOnPlayer) { vm.set(K.keepOn, it) }
                Item("Затухание таймера сна: ${s.fadeSec} сек") { Slider(s.fadeSec.toFloat(), { vm.set(K.fade, it.toInt()) }, valueRange = 0f..30f, steps = 29) }
            }
            item {
                Header("Библиотека и источники")
                Item("Добавление") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onAddFiles) { Text("Файлы") }
                        FilledTonalButton(onAddFolder) { Text("Папка") }
                        OutlinedButton({ vm.checkMissing() }) { Text("Проверить файлы") }
                    }
                }
                Item("Источники аудио", if (sources.isEmpty()) "Папки не добавлены" else "") {
                    sources.forEach { src ->
                        val ok = vm.importer.hasPermission(src.uri)
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(src.name, style = MaterialTheme.typography.titleSmall)
                                Text(src.uri, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                Text("Файлов: ${src.fileCount} · скан: ${fmtDate(src.lastScan)} · доступ: ${if (ok) "есть" else "утерян"}", style = MaterialTheme.typography.labelSmall,
                                    color = if (ok) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
                                Row {
                                    TextButton({ vm.rescan(src) }) { Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Пересканировать") }
                                    TextButton({ vm.removeSource(src) }) { Text("Убрать") }
                                }
                            }
                        }
                    }
                    if (sources.isNotEmpty()) TextButton({ vm.rescanAll() }) { Text("Пересканировать все") }
                }
            }
            item {
                Header("Статистика")
                val now = System.currentTimeMillis()
                val today = remember { Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }
                val tToday by remember { vm.listened(today) }.collectAsState(0L)
                val t7 by remember { vm.listened(now - 7L * 86_400_000) }.collectAsState(0L)
                val t30 by remember { vm.listened(now - 30L * 86_400_000) }.collectAsState(0L)
                Item("Время прослушивания", "Считается реальное время воспроизведения, а не позиция. Перемотка не в счёт.") {
                    Text("Сегодня: ${fmtDur(tToday)}\n7 дней: ${fmtDur(t7)}\n30 дней: ${fmtDur(t30)}\nВсего: ${fmtDur(stories.sumOf { it.listenedSec })}")
                    Text("Начато историй: ${stories.count { it.playCount > 0 }} · завершено: ${stories.count { it.completed }}", Modifier.padding(top = 4.dp))
                }
                val top = stories.filter { it.listenedSec > 0 }.sortedByDescending { it.listenedSec }.take(3)
                if (top.isNotEmpty()) Item("Чаще всего слушаете") { top.forEach { Text("${it.title} — ${fmtDur(it.listenedSec)}") } }
                val topA = stories.filter { it.author.isNotBlank() }.groupBy { it.author }.mapValues { e -> e.value.sumOf { it.listenedSec } }.filter { it.value > 0 }.entries.sortedByDescending { it.value }.take(3)
                if (topA.isNotEmpty()) Item("Любимые авторы") { topA.forEach { Text("${it.key} — ${fmtDur(it.value)}") } }
                Item("") { TextButton({ confirmReset = true }) { Text("Сбросить статистику") } }
                Text("Все данные хранятся только на устройстве.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}
