package com.mystories.player

import android.app.Application
import androidx.room.Room
import com.mystories.player.data.*
import com.mystories.player.service.SleepTimer
import kotlinx.coroutines.*

class App : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    lateinit var repo: Repository
    lateinit var settings: SettingsStore
    lateinit var importer: Importer
    val sleep by lazy { SleepTimer(appScope) }

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "stories.db").build()
        repo = Repository(db.dao())
        settings = SettingsStore(this)
        importer = Importer(this, db.dao())
    }
}
