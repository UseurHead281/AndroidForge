package ru.togc.storyplayer.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories ORDER BY lastPlayedAt DESC, addedAt DESC") fun observeStories(): Flow<List<Story>>
    @Query("SELECT * FROM stories WHERE id = :id LIMIT 1") suspend fun getStory(id: Long): Story?
    @Query("SELECT * FROM stories WHERE uri = :uri LIMIT 1") suspend fun getByUri(uri: String): Story?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(story: Story): Long
    @Update suspend fun update(story: Story)
    @Delete suspend fun delete(story: Story)
    @Query("UPDATE stories SET positionMs = :position, durationMs = CASE WHEN :duration > 0 THEN :duration ELSE durationMs END, lastPlayedAt = :now WHERE id = :id") suspend fun saveProgress(id: Long, position: Long, duration: Long, now: Long = System.currentTimeMillis())
    @Query("UPDATE stories SET isFavorite = NOT isFavorite WHERE id = :id") suspend fun toggleFavorite(id: Long)
    @Query("UPDATE stories SET isCompleted = :completed WHERE id = :id") suspend fun setCompleted(id: Long, completed: Boolean)
    @Query("UPDATE stories SET title = :title, author = :author WHERE id = :id") suspend fun editMetadata(id: Long, title: String, author: String)
    @Query("UPDATE stories SET positionMs = 0, isCompleted = 0 WHERE id = :id") suspend fun resetProgress(id: Long)
    @Query("UPDATE stories SET playCount = playCount + 1, lastPlayedAt = :now WHERE id = :id") suspend fun recordStart(id: Long, now: Long = System.currentTimeMillis())
    @Query("UPDATE stories SET listenedMs = listenedMs + :elapsedMs WHERE id = :id") suspend fun addListenedTime(id: Long, elapsedMs: Long)
    @Query("SELECT * FROM bookmarks WHERE storyId = :storyId ORDER BY positionMs") fun observeBookmarks(storyId: Long): Flow<List<Bookmark>>
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC") fun observeAllBookmarks(): Flow<List<Bookmark>>
    @Insert suspend fun insertBookmark(bookmark: Bookmark): Long
    @Update suspend fun updateBookmark(bookmark: Bookmark)
    @Delete suspend fun deleteBookmark(bookmark: Bookmark)
}
