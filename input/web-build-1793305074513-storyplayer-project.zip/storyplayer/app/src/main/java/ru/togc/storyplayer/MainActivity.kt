package ru.togc.storyplayer

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.google.common.util.concurrent.ListenableFuture
import ru.togc.storyplayer.data.AppDatabase
import ru.togc.storyplayer.data.Bookmark
import ru.togc.storyplayer.data.Story
import ru.togc.storyplayer.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.map
import java.util.concurrent.ExecutionException

private val android.content.Context.dataStore by preferencesDataStore(name = "settings")
private val AMOLED_KEY = booleanPreferencesKey("amoled_theme")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoryPlayerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryPlayerApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { AppDatabase.get(context).storyDao() }
    val stories by dao.observeStories().collectAsStateWithLifecycle(initialValue = emptyList())
    val allBookmarks by dao.observeAllBookmarks().collectAsStateWithLifecycle(initialValue = emptyList())
    val amoled by context.dataStore.data.map { it[AMOLED_KEY] ?: false }.collectAsStateWithLifecycle(initialValue = false)
    var tab by remember { mutableStateOf("Главная") }
    var selectedStory by remember { mutableStateOf<Story?>(null) }
    var query by remember { mutableStateOf("") }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var playing by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var editStory by remember { mutableStateOf<Story?>(null) }
    var editTitle by remember { mutableStateOf("") }
    var editAuthor by remember { mutableStateOf("") }
    var bookmarkDialog by remember { mutableStateOf(false) }
    var bookmarkTitle by remember { mutableStateOf("") }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var sleepJob by remember { mutableStateOf<Job?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future: ListenableFuture<MediaController> = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                playing = c.isPlaying
                c.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        val uri = mediaItem?.localConfiguration?.uri?.toString()
                        selectedStory = stories.firstOrNull { it.uri == uri } ?: selectedStory
                    }
                })
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose { MediaController.releaseFuture(future) }
    }

    LaunchedEffect(controller, selectedStory?.id) {
        while (true) {
            val c = controller
            if (c != null) {
                currentPosition = c.currentPosition.coerceAtLeast(0)
                duration = c.duration.takeIf { it > 0 } ?: (selectedStory?.durationMs ?: 0L)
                playing = c.isPlaying
                val s = selectedStory
                if (s != null && c.currentMediaItem != null) {
                    withContext(Dispatchers.IO) { dao.saveProgress(s.id, currentPosition, duration) }
                }
            }
            delay(5_000)
        }
    }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        scope.launch(Dispatchers.IO) {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) { }
                val displayName = queryDisplayName(context, uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Аудиоистория"
                val title = displayName.substringBeforeLast('.', displayName)
                if (dao.getByUri(uri.toString()) == null) dao.insert(Story(title = title, uri = uri.toString(), sourceName = displayName))
            }
        }
    }

    val bg = if (amoled) Color.Black else Color(0xFF101014)
    val surface = if (amoled) Color(0xFF09090B) else Color(0xFF1B1B22)
    val accent = Color(0xFFD0BCFF)
    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = surface, primary = accent, secondary = Color(0xFFB9C7FF))) {
        Scaffold(
            containerColor = bg,
            topBar = {
                TopAppBar(
                    title = { Column { Text("Истории", fontWeight = FontWeight.Bold); Text(tab, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
                    actions = { IconButton(onClick = { pickFiles.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.Add, contentDescription = "Добавить аудио") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = bg)
                )
            },
            bottomBar = {
                Column {
                    AnimatedVisibility(selectedStory != null) {
                        selectedStory?.let { story ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp)).background(surface).clickable { tab = "Плеер" }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF39314D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Headphones, contentDescription = null, tint = accent) }
                                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                    Text(story.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                    Text(story.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { if (controller?.isPlaying == true) controller?.pause() else controller?.play() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Пауза" else "Воспроизвести") }
                            }
                        }
                    }
                    NavigationBar(containerColor = surface) {
                        listOf("Главная" to Icons.Default.Home, "Библиотека" to Icons.Default.LibraryMusic, "Закладки" to Icons.Default.Bookmarks, "Настройки" to Icons.Default.Settings).forEach { (label, icon) ->
                            NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                        }
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "Главная" -> HomeScreen(stories, selectedStory, currentPosition, onImport = { pickFiles.launch(arrayOf("audio/*")) }, onOpenLibrary = { tab = "Библиотека" }, onPlay = { playStory(it, stories, controller, dao, scope) { selectedStory = it } }, modifier = Modifier.padding(padding))
                "Библиотека" -> LibraryScreen(stories, query, { query = it }, onPlay = { playStory(it, stories, controller, dao, scope) { selectedStory = it }; tab = "Плеер" }, onFavorite = { s -> scope.launch(Dispatchers.IO) { dao.toggleFavorite(s.id) } }, onEdit = { editStory = it; editTitle = it.title; editAuthor = it.author }, onRemove = { s -> scope.launch(Dispatchers.IO) { dao.delete(s) }; if (selectedStory?.id == s.id) selectedStory = null }, modifier = Modifier.padding(padding))
                "Закладки" -> BookmarksScreen(allBookmarks, stories, onJump = { mark -> val s = stories.firstOrNull { it.id == mark.storyId }; if (s != null) { playStory(s, stories, controller, dao, scope) { selectedStory = it }; controller?.seekTo(mark.positionMs); tab = "Плеер" } }, modifier = Modifier.padding(padding))
                "Настройки" -> SettingsScreen(amoled, onAmoled = { enabled -> scope.launch { context.dataStore.edit { it[AMOLED_KEY] = enabled } } }, onSleep = { minutes -> sleepJob?.cancel(); sleepMinutes = minutes; if (minutes > 0) sleepJob = scope.launch { delay(minutes * 60_000L); controller?.pause(); sleepMinutes = 0 } }, sleepMinutes = sleepMinutes, modifier = Modifier.padding(padding))
                "Плеер" -> PlayerScreen(selectedStory, controller, currentPosition, duration, playing, onBookmark = { bookmarkTitle = "Метка ${formatTime(currentPosition)}"; bookmarkDialog = true }, onReset = { selectedStory?.let { s -> scope.launch(Dispatchers.IO) { dao.resetProgress(s.id) }; controller?.seekTo(0) } }, modifier = Modifier.padding(padding))
                else -> { tab = "Главная" }
            }
        }
    }

    if (editStory != null) AlertDialog(
        onDismissRequest = { editStory = null },
        title = { Text("Изменить историю") },
        text = { Column { OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Название") }, singleLine = true); Spacer(Modifier.height(8.dp)); OutlinedTextField(editAuthor, { editAuthor = it }, label = { Text("Автор") }, singleLine = true) } },
        confirmButton = { TextButton(onClick = { val s = editStory!!; scope.launch(Dispatchers.IO) { dao.editMetadata(s.id, editTitle.trim().ifBlank { s.title }, editAuthor.trim().ifBlank { "Неизвестный автор" }) }; editStory = null }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = { editStory = null }) { Text("Отмена") } }
    )
    if (bookmarkDialog) AlertDialog(
        onDismissRequest = { bookmarkDialog = false }, title = { Text("Новая закладка") },
        text = { OutlinedTextField(bookmarkTitle, { bookmarkTitle = it }, label = { Text("Название") }) },
        confirmButton = { TextButton(onClick = { val s = selectedStory; if (s != null) scope.launch(Dispatchers.IO) { dao.insertBookmark(Bookmark(storyId = s.id, positionMs = currentPosition, title = bookmarkTitle.ifBlank { "Метка ${formatTime(currentPosition)}" })) }; bookmarkDialog = false }) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = { bookmarkDialog = false }) { Text("Отмена") } }
    )
}

private fun playStory(story: Story, stories: List<Story>, controller: MediaController?, dao: ru.togc.storyplayer.data.StoryDao, scope: kotlinx.coroutines.CoroutineScope, select: (Story) -> Unit) {
    select(story)
    scope.launch(Dispatchers.IO) { dao.recordStart(story.id) }
    val c = controller ?: return
    val items = stories.map { s -> MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.author).build()).build() }
    val index = stories.indexOfFirst { it.id == story.id }.coerceAtLeast(0)
    c.setMediaItems(items, index, story.positionMs)
    c.prepare()
    c.play()
}

@Composable
private fun HomeScreen(stories: List<Story>, selected: Story?, position: Long, onImport: () -> Unit, onOpenLibrary: () -> Unit, onPlay: (Story) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Твоя личная аудиотека", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Истории. Твой темп. Твоё пространство.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (stories.isEmpty()) item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surface).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Headphones, null, modifier = Modifier.size(58.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp)); Text("Здесь начинается твоя коллекция", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp)); Text("Добавь MP3, M4A, FLAC или другой аудиофайл с устройства. Файлы остаются у тебя.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(18.dp)); Button(onClick = onImport) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить аудио") }
            }
        } else {
            val resume = selected ?: stories.firstOrNull { it.positionMs > 0 && !it.isCompleted } ?: stories.first()
            item {
                Text("Продолжить слушать", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(MaterialTheme.colorScheme.surface).clickable { onPlay(resume) }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(74.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF39314D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp)) }
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) { Text(resume.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(resume.author, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { if (resume.durationMs > 0) (resume.positionMs.toFloat() / resume.durationMs).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth()) }
                    IconButton(onClick = { onPlay(resume) }) { Icon(Icons.Default.PlayArrow, "Продолжить") }
                }
            }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Недавно добавленные", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); TextButton(onClick = onOpenLibrary) { Text("Вся библиотека") } } }
            items(stories.take(5), key = { it.id }) { StoryRow(it, onClick = { onPlay(it) }) }
        }
    }
}

@Composable
private fun LibraryScreen(stories: List<Story>, query: String, onQuery: (String) -> Unit, onPlay: (Story) -> Unit, onFavorite: (Story) -> Unit, onEdit: (Story) -> Unit, onRemove: (Story) -> Unit, modifier: Modifier = Modifier) {
    val filtered = stories.filter { listOf(it.title, it.author, it.sourceName).any { value -> value.contains(query, ignoreCase = true) } }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(query, onQuery, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Название, автор или файл") }, singleLine = true, shape = RoundedCornerShape(18.dp))
        if (filtered.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (stories.isEmpty()) "Библиотека пока пуста" else "Ничего не найдено", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(filtered, key = { it.id }) { story ->
                var expanded by remember(story.id) { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF39314D)).clickable { onPlay(story) }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Headphones, null, tint = MaterialTheme.colorScheme.primary) }
                    Column(Modifier.weight(1f).clickable { onPlay(story) }.padding(horizontal = 12.dp)) {
                        Text(story.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(story.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        if (story.positionMs > 0) Text("Продолжить с ${formatTime(story.positionMs)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { onFavorite(story) }) { Icon(if (story.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "В избранное", tint = if (story.isFavorite) Color(0xFFFF8A80) else MaterialTheme.colorScheme.onSurfaceVariant) }
                    Box { IconButton(onClick = { expanded = true }) { Icon(Icons.Default.MoreVert, "Действия") }; DropdownMenu(expanded, { expanded = false }) { DropdownMenuItem(text = { Text("Воспроизвести") }, onClick = { expanded = false; onPlay(story) }); DropdownMenuItem(text = { Text("Изменить данные") }, onClick = { expanded = false; onEdit(story) }); DropdownMenuItem(text = { Text("Удалить из библиотеки") }, onClick = { expanded = false; onRemove(story) }) } }
                }
            }
        }
    }
}

@Composable
private fun StoryRow(story: Story, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF39314D)), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = MaterialTheme.colorScheme.primary) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(story.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(story.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        IconButton(onClick = onClick) { Icon(Icons.Default.PlayArrow, "Воспроизвести") }
    }
}

@Composable
private fun BookmarksScreen(bookmarks: List<Bookmark>, stories: List<Story>, onJump: (Bookmark) -> Unit, modifier: Modifier = Modifier) {
    if (bookmarks.isEmpty()) Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Bookmarks, null, modifier = Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)); Text("Закладок пока нет", style = MaterialTheme.typography.titleLarge); Text("Сохраняй важные моменты в плеере", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    else LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(bookmarks, key = { it.id }) { b ->
            val story = stories.firstOrNull { it.id == b.storyId }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).clickable { onJump(b) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bookmark, null, tint = Color(b.color)); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(b.title, fontWeight = FontWeight.SemiBold); Text("${story?.title ?: "История недоступна"} · ${formatTime(b.positionMs)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Icon(Icons.Default.PlayArrow, "Перейти")
            }
        }
    }
}

@Composable
private fun PlayerScreen(story: Story?, controller: MediaController?, position: Long, duration: Long, playing: Boolean, onBookmark: () -> Unit, onReset: () -> Unit, modifier: Modifier = Modifier) {
    if (story == null) Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Выбери историю в библиотеке") }
    else Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(36.dp)).background(Color(0xFF272333)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Headphones, null, modifier = Modifier.size(100.dp), tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.height(28.dp)); Text(story.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2); Text(story.author, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(26.dp)); Slider(value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f, onValueChange = { if (duration > 0) controller?.seekTo((it * duration).toLong()) }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), style = MaterialTheme.typography.labelMedium); Text(formatTime(duration), style = MaterialTheme.typography.labelMedium) }
        Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            IconButton(onClick = { controller?.seekBack() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Default.Replay10, "Назад на 10 секунд", modifier = Modifier.size(32.dp)) }
            FilledIconButton(onClick = { if (playing) controller?.pause() else controller?.play() }, modifier = Modifier.size(76.dp)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Пауза" else "Воспроизвести", modifier = Modifier.size(42.dp)) }
            IconButton(onClick = { controller?.seekForward() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Default.Forward10, "Вперёд на 10 секунд", modifier = Modifier.size(32.dp)) }
        }
        Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { OutlinedButton(onClick = onBookmark) { Icon(Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(6.dp)); Text("Закладка") }; OutlinedButton(onClick = onReset) { Icon(Icons.Default.RestartAlt, null); Spacer(Modifier.width(6.dp)); Text("Сначала") } }
        Spacer(Modifier.height(10.dp)); TextButton(onClick = { controller?.playbackParameters = androidx.media3.common.PlaybackParameters(if ((controller?.playbackParameters?.speed ?: 1f) >= 1.2f) 1f else 1.25f) }) { Text("Скорость: ${"%.2f".format(controller?.playbackParameters?.speed ?: 1f)}× · нажми для 1,25×/1×") }
    }
}

@Composable
private fun SettingsScreen(amoled: Boolean, onAmoled: (Boolean) -> Unit, onSleep: (Int) -> Unit, sleepMinutes: Int, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Внешний вид", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Чёрная AMOLED-тема", fontWeight = FontWeight.SemiBold); Text("Чёрный фон для OLED-экранов", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(amoled, onAmoled) } }
        item { Text("Таймер сна", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) { Text(if (sleepMinutes > 0) "Осталось: $sleepMinutes мин" else "Остановить воспроизведение через", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(15, 30, 45, 60).forEach { m -> FilterChip(selected = sleepMinutes == m, onClick = { onSleep(m) }, label = { Text("$m мин") }) }; if (sleepMinutes > 0) TextButton(onClick = { onSleep(0) }) { Text("Отмена") } } } }
        item { Text("Данные и приватность", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Text("Аудиофайлы остаются на устройстве. Библиотека, прогресс и закладки хранятся локально. Для доступа к файлам используется системный выбор Android.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("Версия 0.1.0 · локальный плеер", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val seconds = ms / 1000
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
} catch (_: Exception) { null }
